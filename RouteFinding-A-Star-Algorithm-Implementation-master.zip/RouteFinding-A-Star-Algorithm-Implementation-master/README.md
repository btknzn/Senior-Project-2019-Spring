# RouteFinding-A-Star-Algorithm-Implementation


- pipenv install


- pipenv shell


- python route_finder.py
