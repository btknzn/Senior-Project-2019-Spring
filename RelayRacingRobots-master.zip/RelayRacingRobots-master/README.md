# RelayRacingRobots

- pipenv install


- pipenv shell

For brain:
- git clone
- git submodule init
- git submodule update
- pip install opencv-python
- cd brain
- python brain.py

For controller:

- cd controller
- python controller.py
